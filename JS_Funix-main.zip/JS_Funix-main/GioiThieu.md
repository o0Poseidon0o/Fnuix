# MÔN HỌC : JAVASCRIPT

## 1. Sơ đồ tư duy

Phần sơ đồ tư duy này, các bạn nên tải ứng dụng Xmind về cài đặt, rồi mở file lên để xem nhé
Link tải phần mềm : https://www.xmind.net/
==> lưu ý, với phần mền này, ta có thể chuyển đổi định dạng file về dạng file. pdf hay các dạng file ảnh để có thể tiện khi xem trên điện thoại đều được nhá !

LƯU Ý : và quan trọng nhất là sơ đồ tư duy này mình làm theo ý của mình, phù hợp với mình, nên các bạn chỉ nên tham khảo và cố gắng tự note lại kiến thức thì sẽ hiểu sâu hơn, sau này có quên thì xem lại cũng dể nhé !

## 2. Phần cái file bài 1 2 3... đến bài 16

- Mình chỉ node các phần mình xem là quan trọng và trọng tâm để giới thiệu đến các bạn dể nắm bắt nhất, nên có thể nó không đầy đủ tất cả hoặc có thể là dư hoặc nhiều những cái mới nữa, nên các bạn cũng nên tham khảo là chính nhé ! Đừng lấy nó làm tào liệu chính để học, chính thống nhất vẫn là các tài liệu mà khóa học cung cấp.

- À và các file này sau mỗi buổi chia sẽ vào 2 4 6 mình sẽ cập nhật thêm các file lên cho các bạn nào muốn tham khảo thì tham khảo nhé ! ^^
<hr>
==> OK ! Đôi lời thế thôi, chúc các bạn học tập tốt nhé !
"Hãy theo đuổi đam mê ! Thành công sẽ theo đuổi bạn !"
