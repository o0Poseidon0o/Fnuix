document.querySelector("h1").style.color = "red";
