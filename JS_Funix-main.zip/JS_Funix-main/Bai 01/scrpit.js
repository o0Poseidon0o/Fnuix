// const country = "Việt Nam";
// const continent = "asia";
// let population = 97;

// console.log(country);
// console.log(continent);
// console.log(population);

// // int a = 10;
// // a = "string";

// let a = 12;
// console.log(a, typeof a);

// // đây là comment 1
// // a = "string";

// /**
//  * ggsg
//  * hhshs
//  * hhshs
//  *
//  */

// a = "Hello";

// console.log(a, typeof a);

// let value1 = 12;
// value1 = 14;

// const values = 100; // phải khỏi tạo giá trị đầu

// x = 10;
// console.log(window.x);

let num = 12;
// console.log(!true && !false);

if (num >= 12) {
  console.log("num > 15");
}

console.log(12 + 3 + 10 * 3); // ==> 15 + 30 = 45

// tinh tong cua 2 so sô chan ;
