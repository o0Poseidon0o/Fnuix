let num = 0;

while (true) {
  if (num === 11) break;
  console.log(num);
  num++;
}
